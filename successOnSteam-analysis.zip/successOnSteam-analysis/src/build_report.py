"""Builds docs/report.pdf from the figures and tables produced by notebooks/analysis.ipynb.
Run after the notebook:  python src/build_report.py"""
import json
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

ROOT = Path(__file__).resolve().parent.parent
FIG, TAB, OUT = ROOT / "figures", ROOT / "data" / "processed", ROOT / "docs" / "report.pdf"
REPO_URL = "https://github.com/NexaArmaan/successOnSteam"

D = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("Sans", D + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("Sans-B", D + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Sans-I", D + "DejaVuSans-Oblique.ttf"))
pdfmetrics.registerFont(TTFont("Sans-BI", D + "DejaVuSans-BoldOblique.ttf"))
from reportlab.lib.fonts import addMapping
addMapping("Sans", 0, 0, "Sans"); addMapping("Sans", 1, 0, "Sans-B"); addMapping("Sans", 0, 1, "Sans-I"); addMapping("Sans", 1, 1, "Sans-BI")

INK, INK2, BLUE, RULE, FILL = colors.HexColor("#0b0b0b"), colors.HexColor("#52514e"), colors.HexColor("#2a78d6"), colors.HexColor("#d9d8d3"), colors.HexColor("#f4f3ef")
body = ParagraphStyle("body", fontName="Sans", fontSize=9.6, leading=13.6, textColor=INK, spaceAfter=6)
small = ParagraphStyle("small", parent=body, fontSize=8, leading=10.5, textColor=INK2)
cell = ParagraphStyle("cell", parent=body, fontSize=8, leading=10, spaceAfter=0)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Sans-B")
h1 = ParagraphStyle("h1", parent=body, fontName="Sans-B", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6, textColor=INK)
h2 = ParagraphStyle("h2", parent=body, fontName="Sans-B", fontSize=11, leading=14, spaceBefore=8, spaceAfter=4, textColor=BLUE)
title = ParagraphStyle("title", parent=body, fontName="Sans-B", fontSize=22, leading=27, spaceAfter=4)
sub = ParagraphStyle("sub", parent=body, fontSize=11, leading=15, textColor=INK2)
cap = ParagraphStyle("cap", parent=small, alignment=TA_CENTER, spaceAfter=10)
callout = ParagraphStyle("callout", parent=body, fontSize=10, leading=14.5, backColor=FILL, borderPadding=(8, 10, 8, 10),
                         borderColor=BLUE, borderWidth=0, leftIndent=10, rightIndent=10, spaceBefore=6, spaceAfter=14)

P = lambda t, s=body: Paragraph(t, s)
W = letter[0] - 1.6 * inch


def fig(name, caption, width=W, head=None):
    from PIL import Image as PI
    w, h = PI.open(FIG / f"{name}.png").size
    pre = [P(head, h2)] if head else []
    return KeepTogether(pre + [Image(str(FIG / f"{name}.png"), width=width, height=width * h / w), P(caption, cap)])


def table(rows, widths, header=True, zebra=True):
    data = [[P(str(c), cellb if (header and i == 0) else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, 0), 0.8, INK2),
          ("LINEBELOW", (0, -1), (-1, -1), 0.5, RULE), ("TOPPADDING", (0, 0), (-1, -1), 3),
          ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("LEFTPADDING", (0, 0), (-1, -1), 4)]
    if zebra:
        st += [("BACKGROUND", (0, i), (-1, i), FILL) for i in range(2, len(rows), 2)]
    t.setStyle(TableStyle(st))
    return t


def footer(c, doc):
    c.saveState(); c.setFont("Sans", 7.5); c.setFillColor(INK2)
    c.drawString(0.8 * inch, 0.5 * inch, "What makes a game successful on Steam? — Group 4")
    c.drawRightString(letter[0] - 0.8 * inch, 0.5 * inch, f"{doc.page}")
    c.restoreState()


k = json.loads((TAB / "key_numbers.json").read_text())
num = pd.read_csv(TAB / "summary_numeric.csv")
feat = pd.read_csv(TAB / "summary_features.csv", index_col=0)
tests = pd.read_csv(TAB / "statistical_tests.csv")
reg_p = pd.read_csv(TAB / "regression_popularity.csv", index_col=0)
reg_s = pd.read_csv(TAB / "regression_satisfaction.csv", index_col=0)
clean = pd.read_csv(TAB / "steam_games_clean.csv")
s = []

# ------------------------------------------------------------------ title page
s += [Spacer(1, 0.6 * inch), P("What makes a game successful on Steam?", title),
      P("Data cleaning, exploratory and statistical analysis of 200 Steam games", sub), Spacer(1, 6),
      P("Group 4: Armaan Arora, Shil Patel, D'Angelo Prepetit, Timothy Bas", small),
      P(f'GitHub: <link href="{REPO_URL}" color="#2a78d6">{REPO_URL}</link>', small), Spacer(1, 14)]
s.append(P(
    "<b>The short answer.</b> What makes a Steam game <i>big</i> and what makes players <i>happy</i> are two different things. "
    "Design features such as in-app purchases, mod support and a higher price go with many times more reviews, "
    "but no genre, camera perspective, art style or narrative feature reliably raises the share of positive reviews. "
    "Popularity is largely a matter of scale; satisfaction depends on things these labels don't capture.", callout))

s += [P("1. The question", h1),
      P("<b>Research question:</b> Which characteristics of games on Steam (genre, price, camera perspective, visual style, "
        "narrative elements and gameplay features) are associated with higher <b>player satisfaction</b> and higher "
        "<b>popularity</b>?"),
      P("We measure the two kinds of success separately:"),
      table([["Outcome", "Measure", "Why this measure"],
             ["Satisfaction", "% positive reviews = positive / (positive + negative)",
              "Steam's own player verdict. Only games with at least 10 reviews are used, because 1 of 1 = 100% is noise."],
             ["Popularity", "log10(number of reviews)",
              "Review counts are the most reliable reach measure we have (SteamSpy owners are coarse ranges). "
              "They range from 1 to 1.4 million, so a log scale is used."]], [1.0 * inch, 2.1 * inch, W - 3.1 * inch]),
      Spacer(1, 6),
      P("<b>Why it matters.</b> Over ten thousand games launch on Steam each year, and most developers are small teams "
        "deciding what kind of game to make. If certain genres, styles or features really do lead to better-received games, "
        "that is useful guidance; if they don't, it is just as useful to know that copying the features of hits is not a recipe for success.")]

s += [P("2. Data", h1),
      P("All data was collected by our own scripts from four public APIs (Section 2 of the README). "
        "We sampled 200 games with a fixed random seed — about a third each from the top, middle and lower popularity tiers "
        "of SteamSpy's catalog — and joined them with the Steam Store API (genres, features, price, release date), "
        "the Steam Reviews API (review counts and % positive) and SteamSpy community tags (camera perspective, art style, narrative)."),
      table([["Source", "What it provides", "Rows"],
             ["SteamSpy catalog", "Sampling frame, owner-count ranges, tier", "200"],
             ["SteamSpy app details", "Community tags with vote counts (perspective, art style, narrative), languages, CCU", "200"],
             ["Steam Store API", "Genres, gameplay categories, price, release date", "200"],
             ["Steam Reviews API", "Positive / negative review counts, rating label", "200"]],
            [1.6 * inch, W - 2.2 * inch, 0.6 * inch])]

# ------------------------------------------------------------------ cleaning
s += [P("3. Data cleaning and preprocessing", h1),
      P("The four sources don't line up out of the box. Cleaning is fully scripted in <font face='Sans-I'>src/clean_data.py</font>, "
        "which never edits the raw files and writes a log of every decision. The main steps:"),
      table([["Problem found", "How we handled it", "Games"],
             ["Sources use different names (\"Battlefield 1\" vs \"Battlefield™ 1\")", "Joined on the numeric appid, never on name", "8 differ"],
             ["Reviews CSV stored twice (repo root and data/)", "Checked: identical apart from timestamps; used one copy", "—"],
             ["Owners stored as text range \"50,000 .. 100,000\"", "Parsed to numeric low / high / midpoint", "200"],
             ["Several genres / features packed in one cell", "Split into lists, then one True/False column per feature", "200"],
             ["Untranslated labels (#category_contrast_controls), \"VR Support\" vs \"VR Supported\"", "Mapped to readable labels and merged duplicates", "6"],
             ["$0 price on games that are not free-to-play (delisted, e.g. FIFA 23)", "<b>Missing value</b>, not \"free\"; excluded from price analyses only", "12"],
             ["Release date stored as text; one missing", "Parsed to dates; missing one excluded from date analyses only", "1"],
             ["Rating label replaced by \"3 user reviews\"", "Re-labelled \"Too few reviews\"", "15"],
             ["% positive meaningless for tiny samples", "<b>Outlier / reliability rule:</b> games with &lt;10 reviews excluded from satisfaction tests; a Bayesian-shrunk score kept as a robustness check", "15"],
             ["Review counts extremely right-skewed (skew = 5.9)", "log10 transform (skew after = 0.2)", "200"],
             ["Price outliers above the IQR fence ($45.49)", "Flagged but <b>kept</b>: real AAA list prices, not errors", "6"],
             ["Dead fields (SteamSpy score_rank, userscore always empty)", "Dropped", "200"],
             ["No official perspective / art-style / narrative field", "Derived from community tags, e.g. First-Person, Pixel Graphics, Story Rich", "200"]],
            [2.45 * inch, W - 3.15 * inch, 0.7 * inch]),
      Spacer(1, 6),
      P(f"<b>Result:</b> one analysis table of {k['n_games']} games × 68 columns (<font face='Sans-I'>data/processed/steam_games_clean.csv</font>). "
        f"{k['n_sat']} games have enough reviews for the satisfaction analysis.")]

# ------------------------------------------------------------------ summary stats
s += [P("4. Summary statistics", h1)]
rows = [["Variable", "n", "Mean", "Median", "SD", "Min", "Max"]]
fmt = lambda v: f"{v:,.1f}" if abs(v) < 100 else f"{v:,.0f}"
for _, r in num.iterrows():
    if r.Variable == "Release year":
        rows.append([r.Variable, int(r.n), f"{r.Mean:.1f}", f"{r.Median:.0f}", f"{r.SD:.1f}", f"{r.Min:.0f}", f"{r.Max:.0f}"])
    else:
        rows.append([r.Variable, int(r.n), fmt(r.Mean), fmt(r.Median), fmt(r.SD), fmt(r.Min), fmt(r.Max)])
s += [table(rows, [2.2 * inch] + [(W - 2.2 * inch) / 6] * 6), Spacer(1, 4),
      P("Means are far above medians for reviews, owners and CCU: a few mega-hits (up to 1.4 M reviews) pull the mean up, "
        "which is why medians and log scales are used throughout. The typical game has 564 reviews, costs $10 and is 85% positive.", small)]

fc = feat["games"].astype(int)
groups = [("Genre (Store)", ["Indie", "Action", "Adventure", "Strategy", "RPG", "Casual", "Simulation", "Free to play"]),
          ("Gameplay (Store)", ["Multiplayer", "Achievements", "Full controller support", "Steam Workshop (mods)", "In-app purchases", "Early access"]),
          ("Perspective (tags)", ["First-person", "Third-person", "Top-down / isometric", "2D"]),
          ("Art style (tags)", ["Stylized / cartoon", "Pixel art", "Realistic", "Anime", "Minimalist"]),
          ("Narrative (tags)", ["Story rich", "Choices matter", "Any narrative tag"])]
rows = [["Group", "Counts (games out of 200)"]]
for g, items in groups:
    rows.append([g, ";  ".join(f"{i} {fc[i]}" for i in items)])
pb = clean.price_band.value_counts()
rows.append(["Price band", ";  ".join(f"{b} {pb.get(b, 0)}" for b in ["Free", "$0.01-4.99", "$5-9.99", "$10-19.99", "$20+"]) + ";  missing 12"])
rl = clean.rating_label.value_counts()
rows.append(["Steam rating", ";  ".join(f"{a} {b}" for a, b in rl.items())])
s += [Spacer(1, 8), P("Counts for categorical variables", h2), table(rows, [1.3 * inch, W - 1.3 * inch])]

# ------------------------------------------------------------------ EDA
s += [PageBreak(), P("5. Exploratory analysis", h1),
      fig("fig1_outcome_distributions", "Figure 1. Popularity spans six orders of magnitude; satisfaction is bunched near the top.", head="5.1  The two outcomes look completely different"),
      P("Popularity is spread across six orders of magnitude, with a dip between ~1,000 and ~10,000 reviews that reflects the three sampled tiers. "
        "Satisfaction is skewed the other way: most games are well liked (median 84.6%, IQR 70–91%), so differences between groups are measured in a few points."),
      fig("fig2_popularity_vs_satisfaction", "Figure 2. Each dot is a game with ≥10 reviews, coloured by catalog tier.", width=W * 0.88, head="5.2  Popular games are only slightly better liked"),
      P(f"The correlation between popularity and satisfaction is weak (Spearman ρ = {k['rho_pop_sat']:.2f}, p = .002). "
        "Some of the most-reviewed games sit near 55–60%, and many games with a few dozen reviews score above 90%. "
        "<b>Being big and being liked are largely separate kinds of success</b>, so the rest of the analysis treats them separately.")]

s += [fig("fig3_price", "Figure 3. Satisfaction (left) and popularity (right, log scale) by list price. Boxes show the middle 50%, dots are games.", head="5.3  Price"),
      P("Price lines up strongly with popularity — the median $20+ game has about 42,000 reviews versus 64 for games under $5 "
        "(Kruskal-Wallis p &lt; .001, ε² = 0.37). Satisfaction differs much less: games under $5 have the lowest median (77% vs 86% for $5+, "
        "Mann-Whitney p = .03), but the test across all five price bands is not significant (p = .27). Expensive games are mostly big-studio "
        "releases, so price here works as a marker of budget and marketing rather than a lever.")]

s += [PageBreak(), KeepTogether([P("5.4  Which design features matter?", h2),
      P("For each of 28 features we compared games that have it against games that don't, on both outcomes, "
        "with Mann-Whitney tests and a Benjamini-Hochberg correction for the 56 tests (to avoid false positives from testing so many features).")]),
      fig("fig4_feature_effects", "Figure 4. Difference in medians (with − without) and 95% bootstrap confidence intervals. "
          "Filled dots stay significant after the false-discovery-rate correction."),
      P("<b>This is the central finding.</b> On the left, 12 features have significant popularity gaps, many of them huge: games with in-app purchases, "
        "Steam Workshop (mod) support, multiplayer or a third-person camera have roughly 60–200× more reviews; Indie, pixel-art, 2D and "
        "stylized games have far fewer. On the right, almost every confidence interval crosses zero, and <b>none of the 28 features "
        "has a significant satisfaction difference after correction</b>. Workshop support (+4.7 points, uncorrected p = .035) is the only nominal hit.")]

s += [fig("fig5_perspective_artstyle", "Figure 5. Median % positive by dominant perspective and art style tag, with group size and median reviews.", head="5.5  Camera perspective and art style"),
      P("Every perspective and every art style has a median between 81% and 87% positive except Minimalist (74%, only 6 games); "
        "neither grouping is significant (Kruskal-Wallis p = .85 and p = .27). The same groups differ enormously in reach: the median "
        "third-person game has 25,614 reviews, the median 2D game 258."),
      fig("fig6_correlations", "Figure 6. Spearman correlations among numeric variables (games with ≥10 reviews).", width=W * 0.62, head="5.6  Other numeric relationships"),
      P("Popularity moves with every marker of production scale — owners (ρ = 0.87), languages supported (0.57), price (0.51) and number of "
        "Steam features (0.50). The % positive row is pale: no numeric variable correlates with satisfaction above 0.22. "
        "Release year shows no trend in satisfaction (ρ = −0.05, p = .49).")]

# ------------------------------------------------------------------ stats
s += [PageBreak(), P("6. Statistical analysis", h1),
      P("6.1  Hypothesis tests", h2),
      P("Because both outcomes are skewed, we used non-parametric tests (Kruskal-Wallis, Mann-Whitney, Spearman) plus a chi-square test. "
        "α = 0.05 throughout.")]
rows = [["Test", "Comparison", "Statistic", "p", "Effect size", "Result"]]
for _, r in tests.iterrows():
    stat = f"{r.statistic:,.2f}" if r.test != "Mann-Whitney U" else f"U = {r.statistic:,.0f}"
    pv = "< .001" if r.p_value < .001 else f"{r.p_value:.3f}"
    rows.append([r.test, r.comparison, stat, pv, r.effect, "Significant" if r.p_value < .05 else "Not significant"])
s += [table(rows, [1.0 * inch, 2.0 * inch, 0.7 * inch, 0.6 * inch, 1.6 * inch, W - 5.9 * inch]),
      Spacer(1, 4),
      P("Multiplayer games are no more or less likely to be rated ≥80% positive (χ² p = .95). The under-$5 comparison was chosen after "
        "seeing Figure 3, so it should be read as exploratory.", small)]

s += [P("6.2  Multiple regression: holding other factors constant", h2),
      P("The raw popularity gaps could simply reflect <i>which tier</i> a game was sampled from, or how long it has been on sale. "
        "We fit two ordinary least-squares models with heteroskedasticity-robust (HC3) standard errors on the 174 games with complete data. "
        "Both include catalog tier, log price, game age and 15 design features; the satisfaction model also includes popularity."),
      fig("fig7_regression", "Figure 7. Regression coefficients with 95% confidence intervals. Filled dots: p < .05.")]

def rrow(name, key, t, unit):
    r = t.loc[key]; p = "< .001" if r.p < .001 else f"{r.p:.3f}"
    return [name, f"{r.coef:+.2f}{unit}", f"[{r.ci_low:+.2f}, {r.ci_high:+.2f}]", p]
rows = [["Popularity model (log10 reviews)", "Coef.", "95% CI", "p"],
        rrow("Mid tier (vs top)", "C(tier)[T.Mid (page 10)]", reg_p, ""), rrow("Small tier (vs top)", "C(tier)[T.Small (page 30)]", reg_p, ""),
        rrow("log(1 + price)", "np.log1p(price_usd)", reg_p, ""), rrow("In-app purchases", "in_app_purchases", reg_p, ""),
        rrow("Steam Workshop", "workshop", reg_p, ""), rrow("Indie", "genre_indie", reg_p, ""),
        rrow("Multiplayer", "multiplayer", reg_p, ""), rrow("Third-person", "persp_third_person", reg_p, "")]
rows2 = [["Satisfaction model (% positive)", "Coef.", "95% CI", "p"],
         rrow("log10 reviews (10× more)", "log10_reviews", reg_s, " pts"), rrow("Pixel art", "style_pixel_art", reg_s, " pts"),
         rrow("In-app purchases", "in_app_purchases", reg_s, " pts"), rrow("Early access", "early_access", reg_s, " pts"),
         rrow("Multiplayer", "multiplayer", reg_s, " pts"), rrow("log(1 + price)", "np.log1p(price_usd)", reg_s, " pts")]
cw = [W * f for f in (.46, .16, .26, .12)]
s += [table(rows, cw), Spacer(1, 8), table(rows2, cw),
      Spacer(1, 6),
      P(f"<b>Popularity model</b> (adj. R² = {k['pop_r2']:.2f}): the sampling tier explains most of the variation. Once it is held constant, "
        "multiplayer and third-person are no longer significant — they were standing in for big releases. Higher price, in-app purchases "
        "(10<super>0.45</super> ≈ 2.8× more reviews) and Workshop support (≈ 1.9×) remain positive; Indie games get about half as many reviews."),
      P(f"<b>Satisfaction model</b> (adj. R² = {k['sat_r2']:.2f}): it explains little, and most of that comes from popularity itself — within a tier, "
        "a game with 10× more reviews is about 10 points more positive (well-liked games get talked about). Pixel art is the only design feature "
        "with p &lt; .05 (+7 points), and it also holds with the Bayesian-adjusted score, but it is one of 15 features tested and was not "
        "significant in the corrected comparisons, so we treat it as a lead rather than a finding.")]

# ------------------------------------------------------------------ story
s += [PageBreak(), P("7. The story: what we found and why it matters", h1),
      P("<b>Question.</b> Which characteristics of Steam games go with player satisfaction and popularity?"),
      P("<b>Finding 1 — Two different kinds of success.</b> Popularity and satisfaction are only weakly related (ρ = 0.22). "
        "A game can be huge and divisive, or tiny and loved."),
      P("<b>Finding 2 — Features predict reach, mostly because they mark scale.</b> In-app purchases, mod support, multiplayer and big 3D "
        "third-person games have tens to hundreds of times more reviews; Indie, pixel-art and 2D games have far fewer. After controlling for "
        "tier, the strongest remaining signals are price, monetization and mod support — all signs of large, long-lived live-service products."),
      P("<b>Finding 3 — No design label reliably makes players happier.</b> Across 28 features, 5 perspectives and 6 art styles, nothing "
        "significantly changes the share of positive reviews once multiple testing is accounted for. Medians sit between ~80% and ~87% for nearly every group."),
      P("<b>Finding 4 — Cheap games are rated slightly worse.</b> Games under $5 have a lower median (77% vs 86%), though the overall price effect on satisfaction is weak."),
      P("<b>Why it matters.</b> Looking only at the most successful games on Steam suggests a recipe: multiplayer, monetization, mod support, "
        "a realistic 3D camera. Our data shows that recipe describes <i>budget and reach</i>, not how much players enjoy a game. "
        "For a small studio, choosing a fashionable genre or art style is not a shortcut to good reviews — what players reward is execution "
        "quality that these labels don't measure. And because well-reviewed games do attract more reviews within their tier, "
        "satisfaction is itself one of the routes to popularity.", callout),
      P("8. Limitations", h1),
      P("• <b>Sample.</b> 200 games from three SteamSpy popularity tiers — useful for contrast, but not a random sample of all of Steam, and some feature groups are small (n &lt; 25).<br/>"
        "• <b>Tags.</b> Perspective, art style and narrative come from community tags; 33% of games have no perspective tag and 46% no art-style tag.<br/>"
        "• <b>Measures.</b> Review counts undercount players, and % positive is a snapshot from October 2026.<br/>"
        "• <b>Causation.</b> This is observational, cross-sectional data: the results describe associations, not causes."),
      P("9. Reproducibility", h1),
      P(f"Repository: <link href='{REPO_URL}' color='#2a78d6'>{REPO_URL}</link>. "
        "Run <font face='Sans-I'>python src/clean_data.py</font>, then <font face='Sans-I'>notebooks/analysis.ipynb</font> (Run All), then "
        "<font face='Sans-I'>python src/build_report.py</font>. All tables used in this report are written to "
        "<font face='Sans-I'>data/processed/</font> and all charts to <font face='Sans-I'>figures/</font>.")]

OUT.parent.mkdir(exist_ok=True)
SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=0.8 * inch, rightMargin=0.8 * inch, topMargin=0.75 * inch,
                  bottomMargin=0.8 * inch, title="What makes a game successful on Steam?",
                  author="Group 4").build(s, onFirstPage=footer, onLaterPages=footer)
print("wrote", OUT)
