"""
Clean, standardise and merge the four raw sources into one analysis table.

Input  (never modified):
    data/raw/game_ids.csv
    data/raw/steamspy_raw.json
    data/raw/games_data.csv
    data/steam_reviews_summary.csv
Output:
    data/processed/steam_games_clean.csv     one row per game, analysis-ready
    data/processed/cleaning_log.csv          every cleaning decision, with counts

Run from the repo root:  python src/clean_data.py
"""
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

MIN_REVIEWS = 10          # below this, % positive is too noisy to treat as "satisfaction"
PRIOR_N = 50              # strength of the Bayesian prior used for the adjusted score

log = []


def note(step, detail, n):
    log.append({"step": step, "detail": detail, "rows_affected": int(n)})


# --------------------------------------------------------------------------- load
ids = pd.read_csv(RAW / "game_ids.csv")
store = pd.read_csv(RAW / "games_data.csv")
reviews = pd.read_csv(ROOT / "data" / "steam_reviews_summary.csv")
with open(RAW / "steamspy_raw.json", encoding="utf-8") as f:
    spy = pd.DataFrame(json.load(f)["records"].values())

# Duplicate reviews file in repo root: confirm it carries the same numbers, then ignore it.
root_copy = ROOT / "steam_reviews_summary.csv"
if root_copy.exists():
    a = pd.read_csv(root_copy).drop(columns="collected_at").sort_values("appid").reset_index(drop=True)
    b = reviews.drop(columns="collected_at").sort_values("appid").reset_index(drop=True)
    note("duplicates", f"root reviews CSV identical to data/ copy except timestamps: {a.equals(b)}; using data/ copy", len(a))

for name, df in [("ids", ids), ("store", store), ("reviews", reviews), ("steamspy", spy)]:
    d = df["appid"].duplicated().sum()
    note("duplicates", f"duplicate appids in {name}", d)
    df.drop_duplicates("appid", inplace=True)

# --------------------------------------------------------------------------- SteamSpy
spy = spy.rename(columns={"name": "spy_name"})
# owners "50,000 .. 100,000" -> low/high/midpoint (numbers)
own = spy["owners"].str.replace(",", "").str.extract(r"(\d+)\s*\.\.\s*(\d+)").astype(float)
spy["owners_low"], spy["owners_high"] = own[0], own[1]
spy["owners_mid"] = (spy["owners_low"] + spy["owners_high"]) / 2
spy["owners_band"] = spy["owners"]
note("type conversion", "owners range string -> numeric low/high/mid", spy["owners"].notna().sum())

# dead columns
for col in ["score_rank", "userscore"]:
    empty = spy[col].replace({"": np.nan, 0: np.nan}).isna().all()
    note("dropped dead field", f"SteamSpy {col} empty for every game: {empty}", len(spy))
# tags: dict {tag: votes}. Keep as tag set + store votes share for the strongest tag of a group
spy["tags"] = spy["tags"].apply(lambda t: t if isinstance(t, dict) else {})
spy["n_tags"] = spy["tags"].apply(len)
spy["n_languages"] = spy["languages"].fillna("").apply(lambda s: len([x for x in s.split(",") if x.strip()]))
spy = spy[["appid", "spy_name", "developer", "publisher", "owners_low", "owners_high",
           "owners_mid", "owners_band", "ccu", "n_languages", "tags", "n_tags"]]

# --------------------------------------------------------------------------- Store
# Untranslated / inconsistent category labels
CAT_FIX = {
    "#category_contrast_controls": "Contrast Controls",
    "#category_playable_at_your_own_pace": "Playable without Timed Input",
    "VR Support": "VR Supported",
}
n_fixed = store["categories"].fillna("").apply(lambda s: any(k in s.split("; ") for k in CAT_FIX)).sum()
store["categories"] = store["categories"].fillna("").apply(
    lambda s: "; ".join(sorted({CAT_FIX.get(c, c) for c in s.split("; ") if c})))
note("label standardisation", "untranslated '#category_*' keys + 'VR Support'/'VR Supported' merged", n_fixed)

store["genre_list"] = store["genres"].fillna("").apply(lambda s: [g for g in s.split("; ") if g])
store["category_list"] = store["categories"].apply(lambda s: [c for c in s.split("; ") if c])

# Dates
store["release_date_parsed"] = pd.to_datetime(store["release_date"], format="mixed", errors="coerce")
n_bad = store["release_date_parsed"].isna().sum()
note("missing values", "release_date missing/unparseable -> NaT (excluded only from date analyses)", n_bad)
store["release_year"] = store["release_date_parsed"].dt.year

# Price: $0 but not Free-to-Play = delisted / no store price -> missing, not free
is_f2p = store["genre_list"].apply(lambda g: "Free To Play" in g)
zero = store["final_price"] == 0
store["is_free"] = is_f2p
delisted = zero & ~is_f2p
store["price_usd"] = store["initial_price"].where(~delisted, np.nan)   # list price (not sale price)
store.loc[is_f2p, "price_usd"] = 0.0
store["price_missing_delisted"] = delisted
note("missing values", "$0 price on non-free-to-play game (delisted / no price) -> price set to NaN", delisted.sum())
store["on_sale"] = store["final_price"] < store["initial_price"]

store = store.rename(columns={"name": "store_name"})
store = store[["appid", "store_name", "genre_list", "category_list", "price_usd", "is_free",
               "price_missing_delisted", "on_sale", "release_date_parsed", "release_year", "description"]]

# --------------------------------------------------------------------------- Reviews
reviews = reviews.drop(columns="collected_at")
low = reviews["review_score_desc"].str.contains("user reviews", na=False)
reviews["rating_label"] = reviews["review_score_desc"].where(~low, "Too few reviews")
note("label standardisation", "'N user reviews' rating label -> 'Too few reviews'", low.sum())
reviews["n_reviews"] = reviews["total_positive"] + reviews["total_negative"]
reviews["pct_positive"] = reviews["total_positive"] / reviews["n_reviews"] * 100
# Bayesian-adjusted satisfaction: shrink small samples toward the sample mean
global_mean = reviews["total_positive"].sum() / reviews["n_reviews"].sum()
reviews["pct_positive_adj"] = ((reviews["total_positive"] + PRIOR_N * global_mean)
                               / (reviews["n_reviews"] + PRIOR_N) * 100)
reviews["enough_reviews"] = reviews["n_reviews"] >= MIN_REVIEWS
note("outliers / reliability", f"games with < {MIN_REVIEWS} reviews flagged; excluded from satisfaction tests",
     (~reviews["enough_reviews"]).sum())
reviews = reviews[["appid", "rating_label", "total_positive", "total_negative", "n_reviews",
                   "pct_positive", "pct_positive_adj", "enough_reviews"]]

# --------------------------------------------------------------------------- Merge on appid (names differ between sources)
df = (ids.merge(store, on="appid", how="left")
         .merge(reviews, on="appid", how="left")
         .merge(spy, on="appid", how="left"))
mismatch = (df["name"] != df["store_name"]).sum()
note("merge", "joined on appid, not name; games whose name differs between SteamSpy and Store", mismatch)
df = df.drop(columns=["store_name", "spy_name"])
df["tier"] = df["source_page"].map({0: "Top (page 0)", 10: "Mid (page 10)", 30: "Small (page 30)"})

# --------------------------------------------------------------------------- Feature engineering
def has_tag(tags, *names):
    return any(n in tags for n in names)

T = df["tags"]
G = df["genre_list"]
C = df["category_list"]

# genres (Store API, official)
for g in ["Action", "Adventure", "Indie", "RPG", "Strategy", "Simulation", "Casual"]:
    df[f"genre_{g.lower()}"] = G.apply(lambda l, g=g: g in l)
df["genre_f2p"] = df["is_free"]
df["n_genres"] = G.apply(len)

# gameplay (Store categories)
df["multiplayer"] = C.apply(lambda l: any(x in l for x in ["Multi-player", "Online PvP", "Online Co-op", "MMO", "PvP", "Co-op"]))
df["single_player"] = C.apply(lambda l: "Single-player" in l)
df["online_only_mp"] = df["multiplayer"] & ~df["single_player"]
df["achievements"] = C.apply(lambda l: "Steam Achievements" in l)
df["controller_support"] = C.apply(lambda l: "Full controller support" in l)
df["workshop"] = C.apply(lambda l: "Steam Workshop" in l)
df["in_app_purchases"] = C.apply(lambda l: "In-App Purchases" in l)
df["n_categories"] = C.apply(len)

# camera perspective (community tags: no official field exists)
df["persp_first_person"] = T.apply(lambda t: has_tag(t, "First-Person", "FPS"))
df["persp_third_person"] = T.apply(lambda t: has_tag(t, "Third Person", "Third-Person Shooter"))
df["persp_top_down"] = T.apply(lambda t: has_tag(t, "Top-Down", "Isometric", "Top-Down Shooter"))
df["persp_2d"] = T.apply(lambda t: has_tag(t, "2D", "2D Platformer", "Side Scroller"))

def perspective(row):
    if row.persp_first_person: return "First-person"
    if row.persp_third_person: return "Third-person"
    if row.persp_top_down: return "Top-down/Isometric"
    if row.persp_2d: return "2D side-view"
    return "Untagged"
df["perspective"] = df.apply(perspective, axis=1)

# art style
STYLE = {
    "Pixel art": ["Pixel Graphics", "Retro", "8-bit", "16-bit"],
    "Anime": ["Anime"],
    "Realistic": ["Realistic", "Photorealistic"],
    "Stylized/cartoon": ["Stylized", "Cartoony", "Cartoon", "Colorful", "Cute", "Hand-drawn", "Comic Book"],
    "Minimalist": ["Minimalist", "Abstract"],
}
for k, v in STYLE.items():
    df["style_" + re.sub(r"\W+", "_", k.lower())] = T.apply(lambda t, v=v: has_tag(t, *v))

def art_style(tags):
    # strongest-voted style tag wins
    best, best_votes = "Untagged", 0
    for style, names in STYLE.items():
        for n in names:
            if tags.get(n, 0) > best_votes:
                best, best_votes = style, tags[n]
    return best
df["art_style"] = T.apply(art_style)

# narrative
df["narrative_story_rich"] = T.apply(lambda t: has_tag(t, "Story Rich"))
df["narrative_choices"] = T.apply(lambda t: has_tag(t, "Choices Matter", "Multiple Endings", "Choose Your Own Adventure"))
df["narrative_any"] = T.apply(lambda t: has_tag(t, "Story Rich", "Choices Matter", "Multiple Endings",
                                                "Visual Novel", "Interactive Fiction", "Narration",
                                                "Choose Your Own Adventure", "Cinematic"))
df["horror"] = T.apply(lambda t: has_tag(t, "Horror", "Survival Horror", "Psychological Horror"))
df["early_access"] = T.apply(lambda t: has_tag(t, "Early Access")) | G.apply(lambda l: "Early Access" in l)

# price bands
bins = [-0.01, 0, 4.99, 9.99, 19.99, 200]
labels = ["Free", "$0.01-4.99", "$5-9.99", "$10-19.99", "$20+"]
df["price_band"] = pd.cut(df["price_usd"], bins=bins, labels=labels)

# outcomes
df["log10_reviews"] = np.log10(df["n_reviews"] + 1)
df["game_age_years"] = (pd.Timestamp("2026-10-25") - df["release_date_parsed"]).dt.days / 365.25
df["reviews_per_year"] = df["n_reviews"] / df["game_age_years"].clip(lower=0.25)

# outlier screen on price (IQR) - kept, but flagged
q1, q3 = df["price_usd"].quantile([.25, .75])
hi = q3 + 1.5 * (q3 - q1)
df["price_outlier"] = df["price_usd"] > hi
note("outliers / reliability", f"price above IQR fence (${hi:.2f}) flagged, kept (real list prices)", df["price_outlier"].sum())
note("outliers / reliability", "review counts span 1 to 1.4M (heavy right skew) -> log10 transform used", len(df))

df["tag_list"] = T.apply(lambda t: "; ".join(t.keys()))
df["genre_list"] = G.apply("; ".join)
df["category_list"] = C.apply("; ".join)
df = df.drop(columns=["tags"])

df.to_csv(OUT / "steam_games_clean.csv", index=False)
pd.DataFrame(log).to_csv(OUT / "cleaning_log.csv", index=False)
print(f"Saved {len(df)} games x {df.shape[1]} columns to {OUT/'steam_games_clean.csv'}")
print(pd.DataFrame(log).to_string(index=False))
